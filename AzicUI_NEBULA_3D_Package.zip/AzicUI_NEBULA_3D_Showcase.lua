--[[
    AZIC UI — NEBULA 3D SHOWCASE
    Visual demo for the upgraded Azic UI library.
    Replace the raw URL below with the raw URL of your uploaded NEBULA library.
]]

local Library = loadstring(game:HttpGet(
    "https://raw.githubusercontent.com/Azic46/AzicUIV2/refs/heads/main/AzicUI_Pro_Library.lua"
))()

Library:SetAccent(Color3.fromRGB(145, 92, 255))
Library:Set3DEnabled(true)
Library.AnimationSpeed = 1
Library.AmbientEffects = true
Library.NotifySide = "Right"

local Window = Library:CreateWindow({
    Title = "AZIC  /  NEBULA",
    Size = UDim2.fromOffset(760, 520),
    AutoShow = true,
    Resizable = true,
})

local Dashboard = Window:AddTab("Dashboard", "home")
local Controls = Window:AddTab("Controls", "sliders")
local Appearance = Window:AddTab("Appearance", "palette")
local Settings = Window:AddTab("Settings", "settings")

-- DASHBOARD
local Welcome = Dashboard:AddLeftGroupbox("System overview")
Welcome:AddLabel("NEBULA 3D is active.", true)
Welcome:AddLabel("Layered glass • beveled edges • animated accent", true)
Welcome:AddDivider()
Welcome:AddButton({
    Text = "Run visual test",
    Func = function()
        Library:Notify({
            Type = "Success",
            Title = "NEBULA ONLINE",
            Description = "The upgraded Azic UI interface is running.",
            Time = 4,
        })
    end,
})
Welcome:AddButton({
    Text = "Toggle 3D depth",
    Func = function()
        Library.Style3D = not Library.Style3D
        Library:Set3DEnabled(Library.Style3D)
        Library:Notify({
            Title = "Depth style",
            Description = Library.Style3D and "3D depth enabled." or "3D depth disabled.",
            Time = 3,
        })
    end,
})

local Status = Dashboard:AddRightGroupbox("Live status")
Status:AddToggle("NebulaAmbient", {
    Text = "Ambient animation",
    Default = true,
    Callback = function(value)
        Library.AmbientEffects = value
    end,
})
Status:AddToggle("NebulaMotion", {
    Text = "Reduced motion",
    Default = false,
    Callback = function(value)
        Library.ReducedMotion = value
    end,
})
Status:AddLabel("Tip: use the floating A button or RightShift to hide / show the window.", true)

-- CONTROLS
local General = Controls:AddLeftGroupbox("Interactive controls")
General:AddToggle("DemoToggle", {
    Text = "Example toggle",
    Default = true,
    Callback = function(value) print("Example toggle:", value) end,
})
General:AddSlider("DemoSlider", {
    Text = "Intensity",
    Default = 65,
    Min = 0,
    Max = 100,
    Rounding = 0,
    Suffix = "%",
})
General:AddInput("DemoInput", {
    Text = "Profile name",
    Placeholder = "Type something...",
    Callback = function(value) print("Profile:", value) end,
})

local Selection = Controls:AddRightGroupbox("Selection")
Selection:AddDropdown("DemoDropdown", {
    Text = "Interface mode",
    Values = { "Nebula", "Midnight", "Aurora", "Minimal" },
    Default = 1,
})
Selection:AddDropdown("DemoMulti", {
    Text = "Effects",
    Values = { "Glow", "Glass", "Depth", "Pulse" },
    Multi = true,
    Default = { "Glow", "Depth" },
})
Selection:AddLabel("These controls demonstrate the UI library only.", true)

-- APPEARANCE
local ThemeBox = Appearance:AddLeftGroupbox("Accent palette")
ThemeBox:AddButton({ Text = "Violet", Func = function() Library:SetAccent(Color3.fromRGB(145, 92, 255)) end })
ThemeBox:AddButton({ Text = "Cyan", Func = function() Library:SetAccent(Color3.fromRGB(34, 211, 238)) end })
ThemeBox:AddButton({ Text = "Rose", Func = function() Library:SetAccent(Color3.fromRGB(251, 80, 130)) end })
ThemeBox:AddButton({ Text = "Emerald", Func = function() Library:SetAccent(Color3.fromRGB(52, 211, 153)) end })

local Motion = Appearance:AddRightGroupbox("Motion")
Motion:AddSlider("AnimationSpeed", {
    Text = "Animation speed",
    Default = 100,
    Min = 25,
    Max = 200,
    Rounding = 0,
    Suffix = "%",
    Callback = function(value)
        Library.AnimationSpeed = value / 100
    end,
})
Motion:AddButton({
    Text = "Reset accent",
    Func = function() Library:SetAccent(Color3.fromRGB(145, 92, 255)) end,
})

-- SETTINGS
local Menu = Settings:AddLeftGroupbox("Menu")
Menu:AddLabel("Floating A button: open / close", true)
Menu:AddLabel("Keyboard shortcut: RightShift", true)
Menu:AddButton({
    Text = "Show success notification",
    Func = function() Library:Notify({ Type = "Success", Description = "Everything looks good." }) end,
})
Menu:AddButton({
    Text = "Unload library",
    DoubleClick = true,
    Func = function() Library:Unload() end,
})

Library:BuildThemeSection(Settings:AddRightGroupbox("Theme settings"))
Library:BuildConfigSection(Settings:AddRightGroupbox("Config manager"))

Library:Notify({
    Type = "Success",
    Title = "NEBULA 3D LOADED",
    Description = "Welcome to the upgraded Azic UI experience.",
    Time = 5,
})
